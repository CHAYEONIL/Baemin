package baseball.controller;

import baseball.exception.WrongContinueException;
import baseball.utill.BaseBallNumbers;
import baseball.utill.Random;
import baseball.view.Input;
import baseball.view.Output;

public class BaseballController {
    public static void run() {
        runBaseBall();
        checkCountinue();
    }

    private static void runBaseBall() {
        int strikeCount = 0;
        int ballCount = 0;

        Random random = new Random();
        while(strikeCount != 3) {
            BaseBallNumbers baseBallNumbers = new BaseBallNumbers(Input.startMessage());
            ballCount = baseBallNumbers.calculateBallCount(random.randomNumbers());
            strikeCount = baseBallNumbers.calculateStrikeCount(random.randomNumbers());
            Output.printResult(ballCount, strikeCount);
        }
        System.out.println("3개의 숫자를 모두 맞히셨습니다! 게임 종료");
    }

    private static void checkCountinue() {
        String continueMessage = Input.askNextGame();

        if (continueMessage.equals("1")){
            runBaseBall();
            return;
        }

        if (continueMessage.equals("2")){
            System.out.println("게임 종료");
            return;
        }

        throw new WrongContinueException();
    }
}
